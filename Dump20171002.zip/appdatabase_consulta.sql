-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: appdatabase
-- ------------------------------------------------------
-- Server version	5.7.14-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `consulta`
--

DROP TABLE IF EXISTS `consulta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consulta` (
  `con_id` int(11) NOT NULL AUTO_INCREMENT,
  `FK_pac_id` int(11) NOT NULL,
  `FK_med_id` int(11) NOT NULL,
  `con_desc` varchar(45) DEFAULT NULL,
  `con_data` date DEFAULT '0000-00-00',
  `con_peso` varchar(45) DEFAULT NULL,
  `con_pressao` varchar(45) DEFAULT NULL,
  `con_alt_uterina` varchar(45) DEFAULT NULL,
  `con_bati_feto` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`con_id`),
  KEY `FK_con_med_idx` (`FK_med_id`),
  KEY `FK_con_pac_idx` (`FK_pac_id`),
  CONSTRAINT `FK_con_med` FOREIGN KEY (`FK_med_id`) REFERENCES `medico` (`med_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `FK_con_pac` FOREIGN KEY (`FK_pac_id`) REFERENCES `paciente` (`pac_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consulta`
--

LOCK TABLES `consulta` WRITE;
/*!40000 ALTER TABLE `consulta` DISABLE KEYS */;
INSERT INTO `consulta` VALUES (1,1,1,NULL,'2017-06-04','52','110/10','13','136'),(2,1,2,NULL,'2017-08-03','57','110/40','16','140'),(3,2,1,NULL,'2017-08-03',NULL,NULL,NULL,NULL),(4,2,2,NULL,'2017-06-07',NULL,NULL,NULL,NULL),(5,2,3,NULL,'2017-09-02',NULL,NULL,NULL,NULL),(6,1,1,NULL,'2017-07-04','55','110/60','15','144'),(7,1,1,NULL,'2017-08-02','60','110/12','17','144'),(8,2,2,NULL,'2017-07-01','44','110/10','15','140');
/*!40000 ALTER TABLE `consulta` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-10-02 23:57:12
